ONGAANIMALS — Blog/ONG para ajudar animais em situação de rua

Visão geral

Este é um site simples (front-end puro) para a ONG "ONGAANIMALS" com cadastro de usuários e criação de posts. Tudo é salvo localmente no navegador (localStorage). Ideal para prototipagem e testes locais.

Arquivos

- `INDEX.HTML` — página principal com registros, login, criação e listagem de posts.
- `ESTILO.CSS` — estilos do site.
- `CÓDIGOS.JS` — lógica: registro, login, criação de posts, persistência em localStorage.

Como testar localmente

1. Abra a pasta `ONGANIMALS` no seu explorador de arquivos.
2. Abra `INDEX.HTML` no seu navegador (duplo clique) — não é necessário servidor.
3. Registre uma conta, faça login e crie posts. Os dados ficam no localStorage do navegador.

Notas importantes / limitações

- Não há backend: todas as informações (incluindo senhas) ficam no navegador e são armazenadas em texto simples. Não use esse app para dados reais.
- Para produção, será necessário implementar um backend com armazenamento seguro (banco de dados) e hashing de senhas.
- As imagens são usadas por URL; você pode hospedar imagens em um serviço de terceiros ou estender o app para upload.

Próximos passos recomendados

- Criar um backend (Node.js/Express, Firebase ou similar) para autenticação segura e persistência.
- Implementar upload de imagem e validação de entrada no servidor.
- Melhorar UX: confirmações, paginação, filtros por cidade, função de denúncia/resgate.

Se quiser, eu posso:
- Adicionar validação mais robusta no front-end.
- Implementar um backend básico em Node.js com endpoints para usuários e posts.
- Preparar um deploy rápido (GitHub Pages para front-end; Heroku/Vercel para backend).

