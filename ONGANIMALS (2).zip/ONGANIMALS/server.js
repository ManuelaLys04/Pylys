// server.js — servidor Express simples que fornece uma API REST pequena
// Comentários em português explicando cada parte. Objetivo: servir a página estática
// e disponibilizar endpoints para listar e criar "posts" (casos de animais).

const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware: parse JSON e habilitar CORS para permitir chamadas do frontend
app.use(express.json());
app.use(cors());

// Pasta onde deixaremos os dados (arquivo JSON simples)
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'animals.json');

// Função utilitária para carregar dados do arquivo (sincrono para simplicidade)
function loadData() {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    // Se o arquivo não existir ou estiver vazio, retornamos array vazio
    return [];
  }
}

// Salva dados no arquivo (sincrono para simplicidade)
function saveData(data) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Erro ao salvar dados:', err);
    return false;
  }
}

// Endpoint: GET /api/animals -> retorna lista de posts
app.get('/api/animals', (req, res) => {
  const animals = loadData();
  res.json(animals);
});

// Endpoint: POST /api/animals -> cria um novo post
// Espera um corpo JSON: { title, body, location, image, author }
app.post('/api/animals', (req, res) => {
  const { title, body, location, image, author } = req.body || {};
  if (!title || !body) {
    return res.status(400).json({ error: 'title e body são obrigatórios' });
  }

  const items = loadData();
  const newItem = {
    id: Date.now(), // id simples baseado em timestamp
    title,
    body,
    location: location || '',
    image: image || '',
    author: author || 'Anônimo',
    createdAt: new Date().toISOString()
  };
  items.unshift(newItem); // adiciona no começo
  const ok = saveData(items);
  if (!ok) return res.status(500).json({ error: 'falha ao salvar' });
  res.status(201).json(newItem);
});

// Servir arquivos estáticos (a página HTML, CSS, JS) na raiz do projeto
// Assim você pode colocar seu `INDEX.HTML` no mesmo diretório e o servidor o servirá.
app.use(express.static(path.join(__dirname)));

// Rota de saúde simples
app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
